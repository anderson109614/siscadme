package com.example.BackSisCadme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackSisCadmeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackSisCadmeApplication.class, args);
	}

}
